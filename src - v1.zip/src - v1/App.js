import vic from './Assets/images/logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
      <h1>Vic Valenti</h1>
      <h2>Web and Applications Developer</h2>
      <p>I am passionate about building scalable software, progressive apps and creating effective solutions while growing professionally as a developer.</p>
      <img src={vic} className="App-logo" alt="logo" />
      </header>
    </div>
  );
}

export default App;
