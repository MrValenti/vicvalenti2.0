import React from 'react';
import { Header } from '../containers';

const Home = () => {
  return (
    <div>
        <Header />
        {/* <div className="vic1__header section__padding">testing 123</div> */}
    </div>  
  )
}

export default Home