import React from 'react';
import './features.css'

const Features = () => {
  return (
    <div>Features</div>
  )
}

export default Features;