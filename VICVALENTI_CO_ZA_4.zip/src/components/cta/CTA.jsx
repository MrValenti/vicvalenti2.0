import React from 'react';
import './cta.css';

const CTA = () => {
  return (
    <div>cta</div>
  )
}

export default CTA;