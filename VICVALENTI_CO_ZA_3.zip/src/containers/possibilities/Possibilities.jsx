import React from 'react';
import './possibilities.css';

const Possibilities = () => {
  return (
    <div>Possibilities</div>
  )
}

export default Possibilities;