import React from 'react';
import { Routes, Route, Link } from "react-router-dom";
import { Footer, Blog, Features, WhatVIC, Header, Possibilities } from './containers';
import { Brand, CTA, Navbar } from './components';
import './App.css'
import Home from './pages/Home';
import About from './pages/About';
import Contact from './pages/Contact';
import Portfolio from './pages/Portfolio';


const App = () => {
  return (
  <div className="App">
    
    <div className="gradient__bg">
        <Navbar />
      </div>
      <Routes>
        <Route path='/' element={<Home />} />
        <Route path='/about' element={<About />} />
        <Route path='/contact' element={<Contact />} />
        <Route path='/portfolio' element={<Portfolio />} />
      </Routes>
  
      <Footer />
      
     {/* <Brand />
      <WhatVIC />
      <Features />
      <Possibilities />
      <CTA />
      <Blog />*/}
     
    </div>
  )
}

export default App