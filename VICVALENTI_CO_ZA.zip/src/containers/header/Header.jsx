import React from 'react';
import people from '../../assets/people.png';
import ai from '../../assets/ai.png';
import './header.css';
import Box1 from './Box1';

const Header = () => (
  <div className="vic1__header section__padding" id="home">
    <div className="vic1__header-content">
      {<h1 className="gradient__text">Web and Applications Developer</h1>}
      <p> I am passionate about building scalable software, progressive apps and creating effective solutions.</p>
      {/* {<p>Yet bed any for travelling assistance indulgence unpleasing. Not thoughts all exercise blessing. Indulgence way everything joy alteration boisterous the attachment. Party we years to order allow asked of.</p>} */}
    </div>

    <div className="vic1__header-image">
      {/* <img src={ai} /> */}
      <Box1 />
    </div>
  </div>
);

export default Header;
