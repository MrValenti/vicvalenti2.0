import React from 'react';
import { motion } from 'framer-motion';
import './box.css';

const Box1 = () => (
  <div>
    <motion.div
      className='box'
      whileHover={{
        scale: 1.1
      }}
    >

    </motion.div>
  </div>
);

export default Box1;