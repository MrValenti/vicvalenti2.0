import React from 'react';
import './whatVIC.css';

const whatVIC = () => {
  return (
    <div>whatVIC</div>
  )
}

export default whatVIC;