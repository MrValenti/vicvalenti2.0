import React from 'react';
import './article.css';

const Arcticle = () => {
  return (
    <div>
        <h1>Arcticle</h1>
    </div>
  )
}

export default Arcticle;