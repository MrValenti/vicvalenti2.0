import React from 'react';
import './feature.css'

const Feature = () => {
  return (
    <div>feature</div>
  )
}

export default Feature;